# Synthetic Army Housing Utilization & Vacancy Dashboard

## Overview

This project uses fully synthetic housing data to analyze occupancy, vacancy, net utilization, open work orders, and low-utilization buildings across fictional installations.

The dashboard was built in Tableau Public as a portfolio project to demonstrate dashboard development, operational reporting, and executive-ready insight delivery.

## Tableau Dashboard

- **View the live dashboard:** https://public.tableau.com/app/profile/a.m1875/viz/SyntheticArmyHousingUtilizationVacancyDashboard/SyntheticArmyHousingUtilizationVacancyDashboard

## Business Scenario

Leadership needs a repeatable way to monitor housing utilization, identify underused capacity, and review buildings that may need follow-up based on vacancy, utilization, and work order activity.

This project answers questions such as:

1. Which installations have lower net utilization?
2. Where are the largest vacancy counts?
3. How does utilization trend over time?
4. Which buildings should be reviewed first based on low utilization?

## Dataset

The dataset is fully synthetic and safe for public use. It does not contain real government, military, personal, operational, or sensitive data.

Example fields include:

- Installation
- Region
- Building Number
- Housing Type
- Total Beds
- Occupied Beds
- Vacant Beds
- Net Use Percent
- Open Work Orders
- Priority Level
- Month Date

## Key Metrics

- Total Beds
- Occupied Beds
- Vacant Beds
- Net Use %
- Open Work Orders
- Low-Utilization Buildings

## Dashboard Views

The Tableau dashboard includes:

- Net Use % by Installation
- Vacant Beds by Installation
- Net Use % Trend
- Low Utilization Buildings table

## Tools Used

- Tableau Public
- Excel / CSV
- Synthetic Data
- Dashboard Development
- Executive Reporting
- Operational Reporting

## Key Insight

Buildings below target utilization should be reviewed for demand, condition, open work order volume, and reporting accuracy. The dashboard is designed to help move from high-level trends to specific buildings that may require follow-up.

## Portfolio Value

This project demonstrates the ability to take structured operational data and turn it into a clear dashboard product that supports leadership review, prioritization, and data-informed decision-making.
