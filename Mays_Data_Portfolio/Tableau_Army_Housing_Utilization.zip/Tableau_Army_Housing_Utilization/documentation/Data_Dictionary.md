# Data Dictionary

| Field | Description |
|---|---|
| Record_ID | Synthetic record identifier |
| Month_Date | Reporting month date |
| Fiscal_Year | Synthetic fiscal year |
| Month_Name | Month name |
| Month_Year | Month and year label |
| Installation | Fictional installation name |
| Region | Fictional reporting region |
| Command_Area | Fictional command or area grouping |
| Building_Number | Synthetic building identifier |
| Housing_Type | Fictional housing category |
| Design_Category_Code | Synthetic design/category code |
| Total_Beds | Total available bed spaces |
| Occupied_Beds | Number of occupied bed spaces |
| Vacant_Beds | Total beds minus occupied beds |
| Net_Use_Percent | Occupied beds divided by total beds |
| Open_Work_Orders | Synthetic count of open work orders |
| Priority_Level | Synthetic priority category for follow-up |
| Data_Quality_Flag | Synthetic data quality indicator |
