# Tableau Interview Talking Points

## 30-Second Explanation

This is a Tableau portfolio project I built using fully synthetic housing data. I created it to demonstrate the kind of reporting work I do: taking operational data, organizing it into a dashboard, and turning it into information that can support leadership review. The dashboard tracks occupancy, vacancy, net utilization, open work orders, and low-utilization buildings across fictional installations.

## If Asked Whether the Data Is Real

No. The data is fully synthetic. I intentionally avoided using real government, military, personal, operational, or sensitive data. The structure is based on a realistic operational reporting scenario, but the records, installations, and values are fictional.

## What the Dashboard Shows

The dashboard helps identify which fictional installations have lower utilization, where vacancies are concentrated, how utilization trends over time, and which buildings may need follow-up.

## Why Tableau

I built a Tableau version to show that I can communicate a data story using a common BI tool. Tableau is useful for quick visual analysis, interactive dashboards, and public portfolio sharing.

## What I Would Improve Next

The next improvement would be adding drill-down actions from installation-level summaries to building-level details, stronger formatting on the table view, and a formal exception report for low-utilization buildings.
