# Tableau Project Description

## Project Title

Synthetic Army Housing Utilization & Vacancy Dashboard

## Short Description

Interactive Tableau dashboard using fully synthetic housing data to analyze occupancy, vacancy, net utilization, open work orders, and low-utilization buildings across fictional installations.

## Full Description

This Tableau portfolio project demonstrates how operational housing data can be structured, analyzed, and presented through a leadership-ready dashboard. The dashboard focuses on key metrics such as total beds, occupied beds, vacant beds, net utilization, open work orders, and low-utilization buildings.

The project uses fully synthetic data and does not include any real government, military, personal, operational, or sensitive information.

## Tableau Public Link

https://public.tableau.com/app/profile/a.m1875/viz/SyntheticArmyHousingUtilizationVacancyDashboard/SyntheticArmyHousingUtilizationVacancyDashboard

## Suggested Resume / LinkedIn Project Description

Built an interactive Tableau dashboard using synthetic operational housing data to analyze occupancy, vacancy, net utilization, open work orders, and low-utilization buildings across fictional installations. Developed dashboard views to support leadership-style reporting, trend analysis, and prioritization of buildings requiring follow-up.
